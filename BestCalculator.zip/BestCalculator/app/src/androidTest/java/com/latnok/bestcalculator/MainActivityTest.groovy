package com.latnok.bestcalculator

/**
 * Created by k on 8/6/2017.
 */
class MainActivityTest extends R.anim {
}
